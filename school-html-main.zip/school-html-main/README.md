# school-html
Learning HTML in School because part of Curriculm.
